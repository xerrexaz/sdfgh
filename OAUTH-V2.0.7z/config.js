module.exports = {
    prefix: "-",
    token: "",
    client_id: "",
    client_secret: "",
    redirect_uri: "",
    oauth_link: "",
    owners: []
}